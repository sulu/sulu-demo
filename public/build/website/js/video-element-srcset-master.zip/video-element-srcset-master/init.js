// set Event Listeners
// =================================================

if (document.addEventListener) {
    document.addEventListener('DOMContentLoaded', function () {
        videoElementSrcset.init();
    }, false);
}